# RaceDay – PROG6212 Part 2

This repository contains the RaceDay RESTful API for Part 2 of the Programming 2B Portfolio of Evidence.

See `/docs/README.md` for setup instructions, roles, endpoints and submission notes.

Student: Zoe Damika Van Rooy
Student number: ST10466045
GitHub: https://github.com/ST10466045/PROG6112-POE-ZoeDamikaVanRooy
