using Microsoft.EntityFrameworkCore;
using RaceDayApi.Data;
using RaceDayApi.Models;
using Xunit;

namespace RaceDayApi.Tests;

public class BasicApiTests
{
    private static RaceDayDbContext CreateDb()
    {
        var options = new DbContextOptionsBuilder<RaceDayDbContext>()
            .UseInMemoryDatabase(Guid.NewGuid().ToString()).Options;
        return new RaceDayDbContext(options);
    }

    [Fact]
    public async Task User_Email_Is_Unique()
    {
        await using var db=CreateDb();
        db.Users.Add(new User {FirstName="A",LastName="B",Email="a@test.com",PasswordHash="hash",Role="Participant"});
        await db.SaveChangesAsync();
        db.Users.Add(new User {FirstName="C",LastName="D",Email="a@test.com",PasswordHash="hash",Role="Participant"});
        await Assert.ThrowsAsync<DbUpdateException>(()=>db.SaveChangesAsync());
    }

    [Fact]
    public async Task EventType_Can_Be_Created()
    {
        await using var db=CreateDb();
        db.EventTypes.Add(new EventType {TypeName="Running"});
        await db.SaveChangesAsync();
        Assert.Equal(1, await db.EventTypes.CountAsync());
    }

    [Fact]
    public async Task Enrolment_Connects_Participant_Event_And_Category()
    {
        await using var db=CreateDb();
        var u=new User {FirstName="P",LastName="One",Email="p@test.com",PasswordHash="hash",Role="Participant"};
        var t=new EventType {TypeName="Running"};
        db.AddRange(u,t); await db.SaveChangesAsync();
        var e=new Event {OrganiserId=1,EventTypeId=t.EventTypeId,EventName="Test Race",EventDate=DateTime.UtcNow.AddDays(1),Location="Cape Town",Description="Test",Status="Open"};
        db.Events.Add(e); await db.SaveChangesAsync();
        var c=new Category {EventId=e.EventId,CategoryName="10K",DistanceKM=10,MaxParticipants=100,EntryFee=100};
        db.Categories.Add(c); await db.SaveChangesAsync();
        db.Enrolments.Add(new Enrolment {ParticipantId=u.UserId,EventId=e.EventId,CategoryId=c.CategoryId});
        await db.SaveChangesAsync();
        Assert.Equal(1, await db.Enrolments.CountAsync());
    }
}