namespace RaceDayApi.DTOs;

public record RegisterRequest(string FirstName, string LastName, string Email, string Password, string Role, string? Phone);
public record LoginRequest(string Email, string Password);
public record UpdateProfileRequest(string FirstName, string LastName, string Email, string? Phone);
public record EventRequest(int EventTypeId, string EventName, DateTime EventDate, string Location, string Description, string Status);
public record CategoryRequest(string CategoryName, decimal DistanceKM, int MaxParticipants, decimal EntryFee);
public record EnrolmentRequest(int EventId, int CategoryId);
public record StatusRequest(string Status);
public record ResultRequest(int EnrolmentId, TimeSpan FinishTime, int Position, string ResultStatus);