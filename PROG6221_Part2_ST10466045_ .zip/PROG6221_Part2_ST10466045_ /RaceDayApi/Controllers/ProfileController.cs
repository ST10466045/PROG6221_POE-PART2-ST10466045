using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RaceDayApi.Data;
using RaceDayApi.DTOs;
using RaceDayApi.Filters;

namespace RaceDayApi.Controllers;

[ApiController]
[Route("api/profile")]
[SessionAuthorize]
public class ProfileController(RaceDayDbContext db) : ControllerBase
{
    [HttpGet]
    public async Task<IActionResult> Get()
    {
        var id = HttpContext.Session.GetInt32("UserId")!.Value;
        var user = await db.Users.FindAsync(id);
        return user is null ? NotFound() : Ok(new { user.UserId, user.FirstName, user.LastName, user.Email, user.Phone, user.Role, user.CreatedAt });
    }

    [HttpPut]
    public async Task<IActionResult> Update(UpdateProfileRequest request)
    {
        var id = HttpContext.Session.GetInt32("UserId")!.Value;
        var user = await db.Users.FindAsync(id);
        if (user is null) return NotFound();

        if (await db.Users.AnyAsync(x => x.Email == request.Email.ToLower() && x.UserId != id))
            return Conflict(new { message="Email is already in use." });

        user.FirstName=request.FirstName.Trim(); user.LastName=request.LastName.Trim();
        user.Email=request.Email.Trim().ToLowerInvariant(); user.Phone=request.Phone;
        await db.SaveChangesAsync();
        return Ok(new { message="Profile updated.", user.UserId, user.FirstName, user.LastName, user.Email, user.Phone, user.Role });
    }
}