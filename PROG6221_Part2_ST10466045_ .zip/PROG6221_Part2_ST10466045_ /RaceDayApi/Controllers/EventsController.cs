using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RaceDayApi.Data;
using RaceDayApi.DTOs;
using RaceDayApi.Filters;
using RaceDayApi.Models;

namespace RaceDayApi.Controllers;

[ApiController]
[Route("api/events")]
public class EventsController(RaceDayDbContext db) : ControllerBase
{
    [HttpGet]
    public async Task<IActionResult> GetAll([FromQuery] string? search)
    {
        var q = db.Events.Include(x=>x.EventType).Include(x=>x.Categories).AsNoTracking().AsQueryable();
        if (!string.IsNullOrWhiteSpace(search)) q=q.Where(x=>x.EventName.Contains(search) || x.Location.Contains(search));
        return Ok(await q.OrderBy(x=>x.EventDate).Select(x=>new {
            x.EventId,x.EventName,x.EventDate,x.Location,x.Description,x.Status,
            EventType=x.EventType.TypeName,
            Categories=x.Categories.Select(c=>new {c.CategoryId,c.CategoryName,c.DistanceKM,c.MaxParticipants,c.EntryFee})
        }).ToListAsync());
    }

    [HttpGet("{eventId:int}")]
    public async Task<IActionResult> Get(int eventId)
    {
        var e=await db.Events.Include(x=>x.EventType).Include(x=>x.Categories).AsNoTracking().FirstOrDefaultAsync(x=>x.EventId==eventId);
        return e is null ? NotFound(new {message="Event not found."}) : Ok(e);
    }

    [HttpPost]
    [SessionAuthorize("Organiser")]
    public async Task<IActionResult> Create(EventRequest request)
    {
        if (!await db.EventTypes.AnyAsync(x=>x.EventTypeId==request.EventTypeId)) return BadRequest(new {message="Event type not found."});
        var id=HttpContext.Session.GetInt32("UserId")!.Value;
        var e=new Event {OrganiserId=id, EventTypeId=request.EventTypeId, EventName=request.EventName.Trim(), EventDate=request.EventDate,
            Location=request.Location.Trim(), Description=request.Description.Trim(), Status=request.Status.Trim()};
        db.Events.Add(e); await db.SaveChangesAsync();
        return CreatedAtAction(nameof(Get), new {eventId=e.EventId}, e);
    }

    [HttpPut("{eventId:int}")]
    [SessionAuthorize("Organiser")]
    public async Task<IActionResult> Update(int eventId, EventRequest request)
    {
        var id=HttpContext.Session.GetInt32("UserId")!.Value;
        var e=await db.Events.FindAsync(eventId);
        if(e is null) return NotFound();
        if(e.OrganiserId!=id) return Forbid();
        e.EventTypeId=request.EventTypeId;e.EventName=request.EventName.Trim();e.EventDate=request.EventDate;
        e.Location=request.Location.Trim();e.Description=request.Description.Trim();e.Status=request.Status.Trim();
        await db.SaveChangesAsync(); return Ok(e);
    }

    [HttpDelete("{eventId:int}")]
    [SessionAuthorize("Organiser")]
    public async Task<IActionResult> Delete(int eventId)
    {
        var id=HttpContext.Session.GetInt32("UserId")!.Value;
        var e=await db.Events.FindAsync(eventId);
        if(e is null) return NotFound();
        if(e.OrganiserId!=id) return Forbid();
        e.Status="Cancelled"; await db.SaveChangesAsync(); return NoContent();
    }

    [HttpGet("{eventId:int}/categories")]
    public async Task<IActionResult> Categories(int eventId)
    {
        if(!await db.Events.AnyAsync(x=>x.EventId==eventId)) return NotFound();
        return Ok(await db.Categories.Where(x=>x.EventId==eventId).AsNoTracking().ToListAsync());
    }

    [HttpPost("{eventId:int}/categories")]
    [SessionAuthorize("Organiser")]
    public async Task<IActionResult> CreateCategory(int eventId, CategoryRequest request)
    {
        var id=HttpContext.Session.GetInt32("UserId")!.Value;
        var e=await db.Events.FindAsync(eventId);
        if(e is null) return NotFound();
        if(e.OrganiserId!=id) return Forbid();
        if(request.DistanceKM<=0 || request.MaxParticipants<=0 || request.EntryFee<0) return BadRequest(new {message="Category values are invalid."});
        var c=new Category {EventId=eventId,CategoryName=request.CategoryName.Trim(),DistanceKM=request.DistanceKM,MaxParticipants=request.MaxParticipants,EntryFee=request.EntryFee};
        db.Categories.Add(c); await db.SaveChangesAsync(); return CreatedAtAction(nameof(Categories),new {eventId},c);
    }
}