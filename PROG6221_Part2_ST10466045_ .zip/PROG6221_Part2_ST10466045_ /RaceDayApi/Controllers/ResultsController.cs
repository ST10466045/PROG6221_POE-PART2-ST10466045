using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RaceDayApi.Data;
using RaceDayApi.DTOs;
using RaceDayApi.Filters;
using RaceDayApi.Models;

namespace RaceDayApi.Controllers;

[ApiController]
[Route("api/results")]
public class ResultsController(RaceDayDbContext db) : ControllerBase
{
    [HttpPost]
    [SessionAuthorize("Organiser")]
    public async Task<IActionResult> Create(ResultRequest request)
    {
        var id=HttpContext.Session.GetInt32("UserId")!.Value;
        var en=await db.Enrolments.Include(x=>x.Event).FirstOrDefaultAsync(x=>x.EnrolmentId==request.EnrolmentId);
        if(en is null) return NotFound(new {message="Enrolment not found."});
        if(en.Event.OrganiserId!=id) return Forbid();
        if(await db.Results.AnyAsync(x=>x.EnrolmentId==request.EnrolmentId)) return Conflict(new {message="A result already exists."});
        if(request.Position<=0 || request.FinishTime<TimeSpan.Zero) return BadRequest(new {message="Invalid result."});
        var result=new Result {EnrolmentId=request.EnrolmentId,FinishTime=request.FinishTime,Position=request.Position,ResultStatus=request.ResultStatus};
        db.Results.Add(result);en.Status="Completed";await db.SaveChangesAsync();return Created("",result);
    }

    [HttpGet("mine")]
    [SessionAuthorize("Participant")]
    public async Task<IActionResult> Mine()
    {
        var id=HttpContext.Session.GetInt32("UserId")!.Value;
        return Ok(await db.Results.Include(x=>x.Enrolment).ThenInclude(x=>x.Event).Where(x=>x.Enrolment.ParticipantId==id).AsNoTracking()
            .Select(x=>new {x.ResultId,Event=x.Enrolment.Event.EventName,x.FinishTime,x.Position,x.ResultStatus}).ToListAsync());
    }

    [HttpGet("/api/events/{eventId:int}/results")]
    public async Task<IActionResult> EventResults(int eventId)
    {
        if(!await db.Events.AnyAsync(x=>x.EventId==eventId)) return NotFound();
        return Ok(await db.Results.Include(x=>x.Enrolment).ThenInclude(x=>x.Participant).Where(x=>x.Enrolment.EventId==eventId).OrderBy(x=>x.Position).AsNoTracking()
            .Select(x=>new {x.Position,Participant=$"{x.Enrolment.Participant.FirstName} {x.Enrolment.Participant.LastName}",x.FinishTime,x.ResultStatus}).ToListAsync());
    }
}