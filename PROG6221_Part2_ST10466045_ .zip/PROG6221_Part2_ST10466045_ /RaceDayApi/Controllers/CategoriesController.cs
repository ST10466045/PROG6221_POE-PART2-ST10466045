using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RaceDayApi.Data;
using RaceDayApi.DTOs;
using RaceDayApi.Filters;

namespace RaceDayApi.Controllers;

[ApiController]
[Route("api/categories")]
[SessionAuthorize("Organiser")]
public class CategoriesController(RaceDayDbContext db) : ControllerBase
{
    [HttpPut("{categoryId:int}")]
    public async Task<IActionResult> Update(int categoryId, CategoryRequest request)
    {
        var id=HttpContext.Session.GetInt32("UserId")!.Value;
        var c=await db.Categories.Include(x=>x.Event).FirstOrDefaultAsync(x=>x.CategoryId==categoryId);
        if(c is null) return NotFound();
        if(c.Event.OrganiserId!=id) return Forbid();
        c.CategoryName=request.CategoryName.Trim();c.DistanceKM=request.DistanceKM;c.MaxParticipants=request.MaxParticipants;c.EntryFee=request.EntryFee;
        await db.SaveChangesAsync();return Ok(c);
    }

    [HttpDelete("{categoryId:int}")]
    public async Task<IActionResult> Delete(int categoryId)
    {
        var id=HttpContext.Session.GetInt32("UserId")!.Value;
        var c=await db.Categories.Include(x=>x.Event).Include(x=>x.Enrolments).FirstOrDefaultAsync(x=>x.CategoryId==categoryId);
        if(c is null) return NotFound();
        if(c.Event.OrganiserId!=id) return Forbid();
        if(c.Enrolments.Any()) return Conflict(new {message="Category cannot be deleted because it has enrolments."});
        db.Categories.Remove(c);await db.SaveChangesAsync();return NoContent();
    }
}