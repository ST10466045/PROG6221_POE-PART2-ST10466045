using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RaceDayApi.Data;
using RaceDayApi.DTOs;
using RaceDayApi.Filters;
using RaceDayApi.Models;

namespace RaceDayApi.Controllers;

[ApiController]
[Route("api/enrolments")]
public class EnrolmentsController(RaceDayDbContext db) : ControllerBase
{
    [HttpPost]
    [SessionAuthorize("Participant")]
    public async Task<IActionResult> Create(EnrolmentRequest request)
    {
        var participantId=HttpContext.Session.GetInt32("UserId")!.Value;
        var e=await db.Events.FindAsync(request.EventId);
        var c=await db.Categories.FindAsync(request.CategoryId);
        if(e is null || c is null || c.EventId!=request.EventId) return BadRequest(new {message="Event or category is invalid."});
        if(e.EventDate<DateTime.UtcNow) return BadRequest(new {message="This event has already taken place."});
        if(e.Status!="Open") return BadRequest(new {message="This event is not open for enrolment."});
        var count=await db.Enrolments.CountAsync(x=>x.CategoryId==request.CategoryId && x.Status!="Cancelled");
        if(count>=c.MaxParticipants) return Conflict(new {message="Category is full."});
        if(await db.Enrolments.AnyAsync(x=>x.ParticipantId==participantId && x.CategoryId==request.CategoryId && x.Status!="Cancelled"))
            return Conflict(new {message="You are already enrolled in this category."});
        var enrolment=new Enrolment {ParticipantId=participantId,EventId=request.EventId,CategoryId=request.CategoryId,Status="Pending"};
        db.Enrolments.Add(enrolment);await db.SaveChangesAsync();return Created("",enrolment);
    }

    [HttpGet("mine")]
    [SessionAuthorize("Participant")]
    public async Task<IActionResult> Mine()
    {
        var id=HttpContext.Session.GetInt32("UserId")!.Value;
        return Ok(await db.Enrolments.Where(x=>x.ParticipantId==id).Include(x=>x.Event).Include(x=>x.Category).AsNoTracking()
            .Select(x=>new {x.EnrolmentId,Event=x.Event.EventName,x.EventDate,x.Category=x.Category.CategoryName,x.Status}).ToListAsync());
    }

    [HttpPut("{enrolmentId:int}/status")]
    [SessionAuthorize("Organiser")]
    public async Task<IActionResult> UpdateStatus(int enrolmentId, StatusRequest request)
    {
        var id=HttpContext.Session.GetInt32("UserId")!.Value;
        var en=await db.Enrolments.Include(x=>x.Event).FirstOrDefaultAsync(x=>x.EnrolmentId==enrolmentId);
        if(en is null) return NotFound();
        if(en.Event.OrganiserId!=id) return Forbid();
        if(request.Status is not ("Pending" or "Confirmed" or "Cancelled")) return BadRequest(new {message="Invalid status."});
        en.Status=request.Status;await db.SaveChangesAsync();return Ok(en);
    }

    [HttpGet("/api/events/{eventId:int}/enrolments")]
    [SessionAuthorize("Organiser")]
    public async Task<IActionResult> EventEnrolments(int eventId)
    {
        var id=HttpContext.Session.GetInt32("UserId")!.Value;
        var e=await db.Events.FindAsync(eventId);
        if(e is null) return NotFound();
        if(e.OrganiserId!=id) return Forbid();
        return Ok(await db.Enrolments.Where(x=>x.EventId==eventId).Include(x=>x.Participant).Include(x=>x.Category).AsNoTracking()
            .Select(x=>new {x.EnrolmentId,Participant=$"{x.Participant.FirstName} {x.Participant.LastName}",x.Participant.Email,Category=x.Category.CategoryName,x.Status,x.EnrolmentDate}).ToListAsync());
    }
}