using BCrypt.Net;
using Microsoft.EntityFrameworkCore;
using RaceDayApi.Models;

namespace RaceDayApi.Data;

public static class DbSeeder
{
    public static async Task SeedAsync(RaceDayDbContext db)
    {
        if (await db.Users.AnyAsync()) return;

        var organiser1 = new User { FirstName="Lebo", LastName="Mokoena", Email="organiser1@raceday.co.za", PasswordHash=BCrypt.HashPassword("Password123!"), Role="Organiser", Phone="0711111111" };
        var organiser2 = new User { FirstName="Ayesha", LastName="Daniels", Email="organiser2@raceday.co.za", PasswordHash=BCrypt.HashPassword("Password123!"), Role="Organiser", Phone="0722222222" };
        var participant1 = new User { FirstName="Thabo", LastName="Ndlovu", Email="participant1@raceday.co.za", PasswordHash=BCrypt.HashPassword("Password123!"), Role="Participant", Phone="0733333333" };
        var participant2 = new User { FirstName="Mia", LastName="Jacobs", Email="participant2@raceday.co.za", PasswordHash=BCrypt.HashPassword("Password123!"), Role="Participant", Phone="0744444444" };
        db.Users.AddRange(organiser1, organiser2, participant1, participant2);

        var run = new EventType { TypeName="Road Running" };
        var walk = new EventType { TypeName="Walking" };
        var cycle = new EventType { TypeName="Cycling" };
        db.EventTypes.AddRange(run, walk, cycle);
        await db.SaveChangesAsync();

        var e1 = new Event { OrganiserId=organiser1.UserId, EventTypeId=run.EventTypeId, EventName="Cape Sunrise 10K", EventDate=DateTime.UtcNow.AddDays(30), Location="Cape Town", Description="A community 10 km road race.", Status="Open" };
        var e2 = new Event { OrganiserId=organiser1.UserId, EventTypeId=walk.EventTypeId, EventName="Family Fun Walk", EventDate=DateTime.UtcNow.AddDays(45), Location="Mitchells Plain", Description="A family-friendly community walk.", Status="Open" };
        var e3 = new Event { OrganiserId=organiser2.UserId, EventTypeId=cycle.EventTypeId, EventName="Cape Cycle Challenge", EventDate=DateTime.UtcNow.AddDays(60), Location="Cape Town", Description="A recreational cycling event.", Status="Open" };
        db.Events.AddRange(e1,e2,e3);
        await db.SaveChangesAsync();

        db.Categories.AddRange(
            new Category { EventId=e1.EventId, CategoryName="10 KM Open", DistanceKM=10, MaxParticipants=500, EntryFee=150 },
            new Category { EventId=e1.EventId, CategoryName="5 KM Fun Run", DistanceKM=5, MaxParticipants=300, EntryFee=100 },
            new Category { EventId=e2.EventId, CategoryName="5 KM Walk", DistanceKM=5, MaxParticipants=400, EntryFee=80 },
            new Category { EventId=e2.EventId, CategoryName="2 KM Family", DistanceKM=2, MaxParticipants=200, EntryFee=50 },
            new Category { EventId=e3.EventId, CategoryName="40 KM Cycle", DistanceKM=40, MaxParticipants=250, EntryFee=250 }
        );
        await db.SaveChangesAsync();

        var c1 = await db.Categories.FirstAsync(x => x.EventId == e1.EventId && x.CategoryName=="10 KM Open");
        var c2 = await db.Categories.FirstAsync(x => x.EventId == e2.EventId && x.CategoryName=="5 KM Walk");
        db.Enrolments.AddRange(
            new Enrolment { ParticipantId=participant1.UserId, EventId=e1.EventId, CategoryId=c1.CategoryId, Status="Confirmed" },
            new Enrolment { ParticipantId=participant2.UserId, EventId=e2.EventId, CategoryId=c2.CategoryId, Status="Pending" }
        );
        await db.SaveChangesAsync();
    }
}