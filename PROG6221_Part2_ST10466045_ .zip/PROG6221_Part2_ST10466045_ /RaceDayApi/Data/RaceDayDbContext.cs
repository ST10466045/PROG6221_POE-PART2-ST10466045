using Microsoft.EntityFrameworkCore;
using RaceDayApi.Models;

namespace RaceDayApi.Data;

public class RaceDayDbContext(DbContextOptions<RaceDayDbContext> options) : DbContext(options)
{
    public DbSet<User> Users => Set<User>();
    public DbSet<EventType> EventTypes => Set<EventType>();
    public DbSet<Event> Events => Set<Event>();
    public DbSet<Category> Categories => Set<Category>();
    public DbSet<Enrolment> Enrolments => Set<Enrolment>();
    public DbSet<Result> Results => Set<Result>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<User>().HasIndex(x => x.Email).IsUnique();
        modelBuilder.Entity<User>().Property(x => x.Role).HasMaxLength(20).IsRequired();
        modelBuilder.Entity<EventType>().HasIndex(x => x.TypeName).IsUnique();
        modelBuilder.Entity<Category>().Property(x => x.EntryFee).HasColumnType("decimal(10,2)");
        modelBuilder.Entity<Category>().Property(x => x.DistanceKM).HasColumnType("decimal(8,2)");
        modelBuilder.Entity<Enrolment>().HasIndex(x => new { x.ParticipantId, x.CategoryId }).IsUnique();
        modelBuilder.Entity<Result>().HasIndex(x => x.EnrolmentId).IsUnique();

        modelBuilder.Entity<Event>()
            .HasOne(x => x.Organiser).WithMany(x => x.Events)
            .HasForeignKey(x => x.OrganiserId).OnDelete(DeleteBehavior.Restrict);

        modelBuilder.Entity<Event>()
            .HasOne(x => x.EventType).WithMany(x => x.Events)
            .HasForeignKey(x => x.EventTypeId).OnDelete(DeleteBehavior.Restrict);

        modelBuilder.Entity<Category>()
            .HasOne(x => x.Event).WithMany(x => x.Categories)
            .HasForeignKey(x => x.EventId).OnDelete(DeleteBehavior.Cascade);

        modelBuilder.Entity<Enrolment>()
            .HasOne(x => x.Participant).WithMany(x => x.Enrolments)
            .HasForeignKey(x => x.ParticipantId).OnDelete(DeleteBehavior.Restrict);

        modelBuilder.Entity<Enrolment>()
            .HasOne(x => x.Event).WithMany(x => x.Enrolments)
            .HasForeignKey(x => x.EventId).OnDelete(DeleteBehavior.Restrict);

        modelBuilder.Entity<Enrolment>()
            .HasOne(x => x.Category).WithMany(x => x.Enrolments)
            .HasForeignKey(x => x.CategoryId).OnDelete(DeleteBehavior.Restrict);

        modelBuilder.Entity<Result>()
            .HasOne(x => x.Enrolment).WithOne(x => x.Result)
            .HasForeignKey<Result>(x => x.EnrolmentId).OnDelete(DeleteBehavior.Cascade);
    }
}