# RaceDay API Endpoint Plan – Part 2

| HTTP Method | Route | Description | Role Required | Request Body | Expected Response |
|---|---|---|---|---|---|
| POST | /api/auth/register | Register a user | None | firstName, lastName, email, password, role, phone | 201 Created / 400 / 409 |
| POST | /api/auth/login | Authenticate a user and create a session | None | email, password | 200 / 401 |
| POST | /api/auth/logout | End current session | Any | None | 204 |
| GET | /api/profile | Get logged-in profile | Any | None | 200 / 401 |
| PUT | /api/profile | Update logged-in profile | Any | firstName, lastName, email, phone | 200 / 401 / 409 |
| GET | /api/events | Browse upcoming events | None | Query optional | 200 |
| GET | /api/events/{eventId} | Get event details | None | None | 200 / 404 |
| POST | /api/events | Create event | Organiser | eventTypeId, eventName, eventDate, location, description, status | 201 / 400 / 403 |
| PUT | /api/events/{eventId} | Update organiser's event | Organiser | Event fields | 200 / 403 / 404 |
| DELETE | /api/events/{eventId} | Cancel event | Organiser | None | 204 / 403 / 404 |
| GET | /api/events/{eventId}/categories | List categories | None | None | 200 / 404 |
| POST | /api/events/{eventId}/categories | Create category | Organiser | categoryName, distanceKM, maxParticipants, entryFee | 201 / 400 / 403 |
| PUT | /api/categories/{categoryId} | Update category | Organiser | Category fields | 200 / 403 / 404 |
| DELETE | /api/categories/{categoryId} | Delete category | Organiser | None | 204 / 403 / 404 / 409 |
| POST | /api/enrolments | Enrol participant in category | Participant | eventId, categoryId | 201 / 400 / 409 |
| GET | /api/enrolments/mine | View personal enrolments | Participant | None | 200 / 401 |
| PUT | /api/enrolments/{enrolmentId}/status | Update enrolment status | Organiser | status | 200 / 403 / 404 |
| GET | /api/events/{eventId}/enrolments | View event enrolments | Organiser | None | 200 / 403 / 404 |
| POST | /api/results | Record participant result | Organiser | enrolmentId, finishTime, position, resultStatus | 201 / 400 / 403 / 404 |
| GET | /api/results/mine | View personal results | Participant | None | 200 / 401 |
| GET | /api/events/{eventId}/results | View event results | None | None | 200 / 404 |
