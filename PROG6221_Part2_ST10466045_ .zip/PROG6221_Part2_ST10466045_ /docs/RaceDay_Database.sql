IF DB_ID('RaceDayDB') IS NULL CREATE DATABASE RaceDayDB;
GO
USE RaceDayDB;
GO

IF OBJECT_ID('dbo.Results','U') IS NOT NULL DROP TABLE dbo.Results;
IF OBJECT_ID('dbo.Enrolments','U') IS NOT NULL DROP TABLE dbo.Enrolments;
IF OBJECT_ID('dbo.Categories','U') IS NOT NULL DROP TABLE dbo.Categories;
IF OBJECT_ID('dbo.Events','U') IS NOT NULL DROP TABLE dbo.Events;
IF OBJECT_ID('dbo.EventTypes','U') IS NOT NULL DROP TABLE dbo.EventTypes;
IF OBJECT_ID('dbo.Users','U') IS NOT NULL DROP TABLE dbo.Users;
GO

CREATE TABLE Users(
 UserId INT IDENTITY(1,1) PRIMARY KEY,
 FirstName NVARCHAR(80) NOT NULL,
 LastName NVARCHAR(80) NOT NULL,
 Email NVARCHAR(150) NOT NULL UNIQUE,
 PasswordHash NVARCHAR(255) NOT NULL,
 Role NVARCHAR(20) NOT NULL CHECK(Role IN ('Organiser','Participant')),
 Phone NVARCHAR(30) NULL,
 CreatedAt DATETIME2 NOT NULL DEFAULT SYSUTCDATETIME()
);

CREATE TABLE EventTypes(
 EventTypeId INT IDENTITY(1,1) PRIMARY KEY,
 TypeName NVARCHAR(80) NOT NULL UNIQUE
);

CREATE TABLE Events(
 EventId INT IDENTITY(1,1) PRIMARY KEY,
 OrganiserId INT NOT NULL,
 EventTypeId INT NOT NULL,
 EventName NVARCHAR(150) NOT NULL,
 EventDate DATETIME2 NOT NULL,
 Location NVARCHAR(200) NOT NULL,
 Description NVARCHAR(1000) NOT NULL,
 Status NVARCHAR(30) NOT NULL DEFAULT 'Open',
 CONSTRAINT FK_Events_Users FOREIGN KEY(OrganiserId) REFERENCES Users(UserId),
 CONSTRAINT FK_Events_EventTypes FOREIGN KEY(EventTypeId) REFERENCES EventTypes(EventTypeId)
);

CREATE TABLE Categories(
 CategoryId INT IDENTITY(1,1) PRIMARY KEY,
 EventId INT NOT NULL,
 CategoryName NVARCHAR(100) NOT NULL,
 DistanceKM DECIMAL(8,2) NOT NULL CHECK(DistanceKM > 0),
 MaxParticipants INT NOT NULL CHECK(MaxParticipants > 0),
 EntryFee DECIMAL(10,2) NOT NULL CHECK(EntryFee >= 0),
 CONSTRAINT FK_Categories_Events FOREIGN KEY(EventId) REFERENCES Events(EventId)
);

CREATE TABLE Enrolments(
 EnrolmentId INT IDENTITY(1,1) PRIMARY KEY,
 ParticipantId INT NOT NULL,
 EventId INT NOT NULL,
 CategoryId INT NOT NULL,
 EnrolmentDate DATETIME2 NOT NULL DEFAULT SYSUTCDATETIME(),
 Status NVARCHAR(30) NOT NULL DEFAULT 'Pending',
 CONSTRAINT FK_Enrolments_Users FOREIGN KEY(ParticipantId) REFERENCES Users(UserId),
 CONSTRAINT FK_Enrolments_Events FOREIGN KEY(EventId) REFERENCES Events(EventId),
 CONSTRAINT FK_Enrolments_Categories FOREIGN KEY(CategoryId) REFERENCES Categories(CategoryId),
 CONSTRAINT UQ_Enrolments UNIQUE(ParticipantId,CategoryId)
);

CREATE TABLE Results(
 ResultId INT IDENTITY(1,1) PRIMARY KEY,
 EnrolmentId INT NOT NULL UNIQUE,
 FinishTime TIME NOT NULL,
 Position INT NOT NULL CHECK(Position > 0),
 ResultStatus NVARCHAR(30) NOT NULL DEFAULT 'Finished',
 CONSTRAINT FK_Results_Enrolments FOREIGN KEY(EnrolmentId) REFERENCES Enrolments(EnrolmentId)
);
GO

INSERT INTO Users(FirstName,LastName,Email,PasswordHash,Role,Phone) VALUES
('Lebo','Mokoena','organiser1@raceday.co.za','CHANGE_ME','Organiser','0711111111'),
('Ayesha','Daniels','organiser2@raceday.co.za','CHANGE_ME','Organiser','0722222222'),
('Thabo','Ndlovu','participant1@raceday.co.za','CHANGE_ME','Participant','0733333333'),
('Mia','Jacobs','participant2@raceday.co.za','CHANGE_ME','Participant','0744444444');

INSERT INTO EventTypes(TypeName) VALUES ('Road Running'),('Walking'),('Cycling');

INSERT INTO Events(OrganiserId,EventTypeId,EventName,EventDate,Location,Description,Status)
VALUES
(1,1,'Cape Sunrise 10K',DATEADD(day,30,SYSUTCDATETIME()),'Cape Town','A community 10 km road race.','Open'),
(1,2,'Family Fun Walk',DATEADD(day,45,SYSUTCDATETIME()),'Mitchells Plain','A family-friendly community walk.','Open'),
(2,3,'Cape Cycle Challenge',DATEADD(day,60,SYSUTCDATETIME()),'Cape Town','A recreational cycling event.','Open');

INSERT INTO Categories(EventId,CategoryName,DistanceKM,MaxParticipants,EntryFee) VALUES
(1,'10 KM Open',10,500,150),(1,'5 KM Fun Run',5,300,100),
(2,'5 KM Walk',5,400,80),(2,'2 KM Family',2,200,50),(3,'40 KM Cycle',40,250,250);

INSERT INTO Enrolments(ParticipantId,EventId,CategoryId,Status)
VALUES (3,1,1,'Confirmed'),(4,2,3,'Pending');
GO

-- Verification queries
SELECT * FROM Users;
SELECT * FROM EventTypes;
SELECT * FROM Events;
SELECT * FROM Categories;
SELECT * FROM Enrolments;
SELECT * FROM Results;