# RaceDay – Part 2 RESTful API

## Student
Student: Zoe Damika Van Rooy
Student number: ST10466045
Module: PROG6212 Programming 2B

## Project overview
RaceDay is a web-based event management API for road running, walking and cycling events. Organisers manage events, categories, enrolments and results. Participants register, browse events, enrol in categories and view their personal results.

## Roles
**Organiser:** create/edit/cancel events, manage categories, view event enrolments and record results.

**Participant:** register, log in, browse events, enrol in categories, view personal enrolments and view personal results.

## Technology
- ASP.NET Core Web API
- C# / .NET 8
- Entity Framework Core Code-First
- SQL Server
- Swagger/OpenAPI
- xUnit
- GitHub Actions

## API endpoints
| Method | Route | Role |
|---|---|---|
| POST | /api/auth/register | None |
| POST | /api/auth/login | None |
| POST | /api/auth/logout | Any session |
| GET | /api/profile | Any |
| PUT | /api/profile | Any |
| GET | /api/events | None |
| GET | /api/events/{eventId} | None |
| POST | /api/events | Organiser |
| PUT | /api/events/{eventId} | Organiser |
| DELETE | /api/events/{eventId} | Organiser |
| GET | /api/events/{eventId}/categories | None |
| POST | /api/events/{eventId}/categories | Organiser |
| PUT | /api/categories/{categoryId} | Organiser |
| DELETE | /api/categories/{categoryId} | Organiser |
| POST | /api/enrolments | Participant |
| GET | /api/enrolments/mine | Participant |
| PUT | /api/enrolments/{enrolmentId}/status | Organiser |
| GET | /api/events/{eventId}/enrolments | Organiser |
| POST | /api/results | Organiser |
| GET | /api/results/mine | Participant |
| GET | /api/events/{eventId}/results | None |

## Local setup
1. Install Visual Studio 2022 with ASP.NET and web development.
2. Install SQL Server / LocalDB.
3. Open `RaceDayApi.sln`.
4. Restore NuGet packages.
5. Check the connection string in `RaceDayApi/appsettings.json`.
6. Build the solution.
7. Run the API.
8. Open `/swagger` in the browser.
9. Register or use the seeded accounts.

Seeded accounts:
- organiser1@raceday.co.za / Password123!
- organiser2@raceday.co.za / Password123!
- participant1@raceday.co.za / Password123!
- participant2@raceday.co.za / Password123!

## Database
The SQL script is in `/docs/RaceDay_Database.sql`. The API also uses EF Core Code-First and creates the development database automatically when it is not present.

## Testing
Run:
`dotnet test`

## CI/CD
GitHub Actions validates the required repository structure and runs the automated tests.

## Video
Replace this line with the student's unlisted YouTube presentation link:
`[PASTE UNLISTED YOUTUBE LINK HERE]`

## CI screenshot
Replace this section with a screenshot of the successful green GitHub Actions workflow.

## AI disclosure
AI tools were used as a development/planning aid. The student should review, understand, test and adapt all generated material before submission and should use the institution's required AI-disclosure wording if provided.